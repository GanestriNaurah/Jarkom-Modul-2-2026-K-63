# prab & tedd (DNS)
# Run di prab dan tedd

#!/bin/sh
# Soal 20 - Autostart DNS di prab dan tedd

rc-update add named

echo "autostart DNS done!"

# -------------------------------------------------------------------------------------
# obladi & desmond (Apache)
# Run di: obladi dan desmond

#!/bin/sh
# Soal 20 - Autostart Apache di obladi dan desmond

rc-update add apache2

echo "autostart Apache done!"

# -------------------------------------------------------------------------------------
# oblada & molly (Nginx + PHP-FPM)
# Run di oblada dan molly

#!/bin/sh
# Soal 20 - Autostart Nginx + PHP-FPM di oblada dan molly

rc-update add nginx
rc-update add php-fpm84

echo "autostart Nginx + PHP-FPM done!"

# -------------------------------------------------------------------------------------
# penny (Apache + PHP-FPM)
# Run di penny

#!/bin/sh
# Soal 20 - Autostart Apache + PHP-FPM di penny

rc-update add apache2
rc-update add php-fpm84

echo "autostart penny done!"

# -------------------------------------------------------------------------------------
# abbey (Nginx)
# Run di abbey

#!/bin/sh
# Soal 20 - Autostart Nginx di abbey

rc-update add nginx

echo "autostart abbey done!"

# -------------------------------------------------------------------------------------
# rootkit (iptables) - Debian
# Run di rootkit

#!/bin/sh
# Soal 20 - Autostart iptables di rootkit (Debian)

apt update && apt install -y iptables-persistent

update-rc.d netfilter-persistent enable

echo "autostart iptables done!"

# -------------------------------------------------------------------------------------
# Verifikasi Autostart
# Run di masing-masing node

# Alpine nodes
rc-status | grep -E "named|apache2|nginx|php-fpm"

# Debian (rootkit)
ls -la /etc/rc*.d/ | grep netfilter

# Run di penny

#!/bin/sh
# Soal 15 - Proxy Path /eternal di penny - FINAL

apk add php-fpm

mkdir -p /var/www/eternal
echo "<?php echo 'Eternal Page'; ?>" > /var/www/eternal/index.php

# Start PHP-FPM
/usr/sbin/php-fpm84

cat > /etc/apache2/conf.d/penny.conf << 'EOF'
<VirtualHost *:80>
    ServerName penny.k63.com
    ServerAlias www.k63.com

    ProxyPreserveHost On

    ProxyPass /eternal !

    ProxyPass / http://10.95.30.4/
    ProxyPassReverse / http://10.95.30.4/

    RequestHeader set X-Forwarded-For "%{REMOTE_ADDR}s"
    RequestHeader set Host "obladi.k63.com"

    AliasMatch ^/eternal/?$ /var/www/eternal/index.php

    <Directory /var/www/eternal>
        Options +Indexes
        AllowOverride None
        Require all granted
        DirectoryIndex index.php
        <FilesMatch \.php$>
            SetHandler "proxy:fcgi://127.0.0.1:9000"
        </FilesMatch>
    </Directory>

    ErrorLog /var/log/apache2/penny_error.log
    CustomLog /var/log/apache2/penny_access.log combined
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "penny /eternal done!"

# ----------------------------------------------------------------------------------------------------------
# Verifikasi 
# Run di alpha

curl http://www.k63.com/eternal

## Expected Output
## Eternal Page

# ----------------------------------------------------------------------------------------------------------
# Run di abbey

#!/bin/sh
# Soal 15 - Proxy Path /orion di abbey - FINAL

mkdir -p /var/www/orion
echo "<h1>Orion Static</h1>" > /var/www/orion/index.html

rm -f /etc/nginx/conf.d/abbey-redirect.conf
rm -f /etc/nginx/conf.d/abbey-orion.conf

cat > /etc/nginx/conf.d/abbey.conf << 'EOF'
server {
    listen 80;
    server_name abbey.k63.com static.k63.com;

    location = /orion {
        return 301 /orion/;
    }

    location /orion/ {
        root /var/www;
        index index.html;
        try_files $uri $uri/ =404;
    }

    location / {
        proxy_pass http://10.95.30.6;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

nginx -s reload

echo "abbey /orion done!"

# ----------------------------------------------------------------------------------------------------------
# Verifikasi
# Run di alpha 

curl http://static.k63.com/orion
curl http://static.k63.com/orion/

# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------

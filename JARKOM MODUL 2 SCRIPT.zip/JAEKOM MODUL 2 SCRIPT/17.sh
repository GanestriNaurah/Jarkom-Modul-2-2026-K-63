# Run di alpha

dig alpha.k63.com TXT
dig beta.k63.com TXT
dig gamma.k63.com TXT
dig delta.k63.com TXT
dig epsilon.k63.com TXT

# Verifikasi Lengkap
# Run di alpha

# Test semua TXT record
for host in alpha beta gamma delta epsilon; do
    echo "=== $host.k63.com ==="
    dig @10.95.30.2 $host.k63.com TXT +short
done
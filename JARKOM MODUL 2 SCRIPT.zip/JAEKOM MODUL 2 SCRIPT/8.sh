# Verifikasi Reverse DNS
# Run di alpha

dig -x 10.95.20.2
dig -x 10.95.30.4
dig -x 10.95.30.5
dig -x 10.95.30.6
dig -x 10.95.30.7

# -------------------------------------------------------
# Verifikasi dari tedd (slave)
# Run di tedd

dig -x 10.95.20.2
dig -x 10.95.30.4
dig -x 10.95.30.5
dig -x 10.95.30.6
dig -x 10.95.30.7

# --------------------------------------------------------
# Verifikasi Zone Transfer Reverse
# Run di alpha

dig @10.95.30.2 30.95.10.in-addr.arpa axfr
dig @10.95.30.2 20.95.10.in-addr.arpa axfr
# Verifikasi Zone Transfer
# Run di tedd

# Zone transfer dari prab
dig @10.95.30.2 k63.com axfr

# --------------------------------------------------------
# Run di prab
# Edit named.conf.local
cat > /etc/bind/named.conf.local << 'EOF'
zone "k63.com" {
    type master;
    file "/var/bind/pri/db.k63.com";
    allow-transfer { 10.95.30.3; 10.95.10.2; };
    also-notify { 10.95.30.3; };
    forwarders { 192.168.122.1; };
};

zone "30.95.10.in-addr.arpa" {
    type master;
    file "/var/bind/pri/db.30.95.10";
    allow-transfer { 10.95.30.3; 10.95.10.2; };
    also-notify { 10.95.30.3; };
};

zone "20.95.10.in-addr.arpa" {
    type master;
    file "/var/bind/pri/db.20.95.10";
    allow-transfer { 10.95.30.3; 10.95.10.2; };
    also-notify { 10.95.30.3; };
};
EOF

# Restart named
killall named
named -u named

#---------------------------------------------------------
# Verifikasi di tedd
dig @10.95.30.2 k63.com axfr


# -----------------------------------------------------
# Run di alpha

# Cek serial SOA di prab
dig @10.95.30.2 k63.com SOA

# Cek serial SOA di tedd
dig @10.95.30.3 k63.com SOA

# Cek zone transfer
dig @10.95.30.2 k63.com axfr

# Cek reverse zone transfer
dig @10.95.30.2 30.95.10.in-addr.arpa axfr
dig @10.95.30.2 20.95.10.in-addr.arpa axfr
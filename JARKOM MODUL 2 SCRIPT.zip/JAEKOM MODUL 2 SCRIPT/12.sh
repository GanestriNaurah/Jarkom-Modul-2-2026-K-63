# penny (Basic Auth untuk /admin)
# Run di penny

#!/bin/sh
# Soal 12 - Basic Auth di Penny

apk add apache2-utils

# Buat file password
htpasswd -cb /etc/apache2/.htpasswd prabs pakar_pinter_jadi_gob***

# Tambahkan config basic auth
cat >> /etc/apache2/conf.d/penny.conf << 'EOF'

<Location /admin>
    AuthType Basic
    AuthName "Restricted Area"
    AuthUserFile /etc/apache2/.htpasswd
    Require valid-user
</Location>
EOF

# Restart Apache
/usr/sbin/apachectl restart

echo "basic auth done!"

# ------------------------------------------------------------------------
# Verifikasi Soal 12
# Run di alpha

# Tanpa credential (harus ditolak)
curl http://www.k63.com/admin

# Dengan credential (harus berhasil)
curl -u prabs:pakar_pinter_jadi_gob*** http://www.k63.com/admin


# ---------------------------------------------------------------------------------
# Verifikasi File Password
# Run di: penny

cat /etc/apache2/.htpasswd

### Harus keluar: prab:$apr1$...
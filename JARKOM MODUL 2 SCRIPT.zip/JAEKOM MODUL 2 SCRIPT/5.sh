# Script per Node

# rootkit
hostname rootkit
echo "127.0.1.1 rootkit.k63.com rootkit" >> /etc/hosts

# alpha
hostname alpha
echo "127.0.1.1 alpha.k63.com alpha" >> /etc/hosts

# beta
hostname beta
echo "127.0.1.1 beta.k63.com beta" >> /etc/hosts

# gamma
hostname gamma
echo "127.0.1.1 gamma.k63.com gamma" >> /etc/hosts

#delta
hostname delta
echo "127.0.1.1 delta.k63.com delta" >> /etc/hosts

#epsilon
hostname epsilon
echo "127.0.1.1 epsilon.k63.com epsilon" >> /etc/hosts

#abbey
hostname abbey
echo "127.0.1.1 abbey.k63.com abbey" >> /etc/hosts

#penny
hostname penny
echo "127.0.1.1 penny.k63.com penny" >> /etc/hosts

#obladi
hostname obladi
echo "127.0.1.1 obladi.k63.com obladi" >> /etc/hosts

#desmond
hostname desmond
echo "127.0.1.1 desmond.k63.com desmond" >> /etc/hosts

#oblada
hostname oblada
echo "127.0.1.1 oblada.k63.com oblada" >> /etc/hosts

#molly
hostname molly
echo "127.0.1.1 molly.k63.com molly" >> /etc/hosts

# Verifikasi
# Run di masing-masing node

hostname
hostname -f

# Run di alpha

dig alpha.k63.com
dig beta.k63.com
dig gamma.k63.com
dig delta.k63.com
dig epsilon.k63.com
dig abbey.k63.com
dig penny.k63.com
dig obladi.k63.com
dig desmond.k63.com
dig oblada.k63.com
dig molly.k63.com
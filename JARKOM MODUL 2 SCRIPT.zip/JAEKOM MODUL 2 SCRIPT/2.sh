#!/bin/sh
# Soal 2 - NAT di rootkit (Debian)

# Enable IP forwarding
echo 1 > /proc/sys/net/ipv4/ip_forward
echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf

# Buat direktori iptables
mkdir -p /etc/iptables

# Setup NAT MASQUERADE
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

# Simpan iptables
iptables-save > /etc/iptables/rules.v4

echo "NAT done!"

cat /proc/sys/net/ipv4/ip_forward
iptables -t nat -L -v


# -------------------------------------
# Run di alpha atau node lain
ping -c 3 8.8.8.8
# Verifikasi Lengkap
# Run di alpha

# Cek DNS record
dig outbound.k63.com

# Test curl
curl http://outbound.k63.com
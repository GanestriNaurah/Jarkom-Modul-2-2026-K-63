#!/bin/sh
# Soal 3 - Resolver Awal
# Run di alpha, beta, gamma, delta, epsilon, abbey, prab, tedd, obladi, desmond, oblada, molly, penny
echo "nameserver 192.168.122.1" > /etc/resolv.conf
echo "resolver done!"



# --------------------------------------------
# Verifikasi
# Run di alpha atau node lain

# Cek resolver
cat /etc/resolv.conf

# Test internet
ping -c 3 8.8.8.8

# Test DNS
ping -c 1 google.com

# Test koneksi ke rootkit
ping -c 1 10.95.10.1

# Test koneksi ke node lain
ping -c 1 10.95.30.2
ping -c 1 10.95.40.2
# Lanjut ke tedd — DNS Slave
# Run di tedd

#!/bin/sh
# Soal 4 - DNS Slave (tedd) - Alpine

apk add bind bind-tools iproute2 nano openrc

mkdir -p /run/openrc
touch /run/openrc/softlevel
mkdir -p /var/bind/slave
chown named:named /var/bind

cat > /etc/bind/named.conf << 'EOF'
include "/etc/bind/named.conf.options";
include "/etc/bind/named.conf.local";
EOF

cat > /etc/bind/named.conf.options << 'EOF'
options {
    directory "/var/bind";
    listen-on { any; };
    listen-on-v6 { none; };
    allow-query { any; };
    recursion yes;
    allow-recursion { any; };
};
EOF

cat > /etc/bind/named.conf.local << 'EOF'
zone "k63.com" {
    type slave;
    file "/var/bind/slave/db.k63.com";
    masters { 10.95.30.2; };
};

zone "30.95.10.in-addr.arpa" {
    type slave;
    file "/var/bind/slave/db.30.95.10";
    masters { 10.95.30.2; };
};

zone "20.95.10.in-addr.arpa" {
    type slave;
    file "/var/bind/slave/db.20.95.10";
    masters { 10.95.30.2; };
};
EOF

cat > /etc/resolv.conf << 'EOF'
nameserver 10.95.30.2
nameserver 10.95.30.3
nameserver 192.168.122.1
EOF

chown -R named:named /var/bind
named -u named

echo "tedd DNS done!"

# Verifikasi tedd

dig @127.0.0.1 k63.com
dig @10.95.30.3 k63.com
dig @127.0.0.1 -x 10.95.20.2

# ----------------------------------------------------------------------------------------------------
# Update Resolver Semua Non-Router
# Run di: alpha, beta, gamma, delta, epsilon, abbey, obladi, desmond, oblada, molly, penny

cat > /etc/resolv.conf << 'EOF'
nameserver 10.95.30.2
nameserver 10.95.30.3
nameserver 192.168.122.1
EOF

# --------------------------------------------------------------
# Verifikasi dari alpha
dig k63.com
dig www.k63.com
dig -x 10.95.20.2
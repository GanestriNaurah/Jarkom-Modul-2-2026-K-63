# rootkit

ip addr show
ping -c 3 8.8.8.8

# rootkit

ping -c 1 10.95.10.2
ping -c 1 10.95.10.3
ping -c 1 10.95.10.4
ping -c 1 10.95.20.2
ping -c 1 10.95.30.2
ping -c 1 10.95.30.3
ping -c 1 10.95.30.4
ping -c 1 10.95.30.5
ping -c 1 10.95.30.6
ping -c 1 10.95.30.7
ping -c 1 10.95.40.2
ping -c 1 10.95.50.2
ping -c 1 10.95.50.3
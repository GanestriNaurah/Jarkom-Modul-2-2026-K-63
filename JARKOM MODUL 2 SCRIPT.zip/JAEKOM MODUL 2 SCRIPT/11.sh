# penny (Apache) → Vault
# Run di penny

#!/bin/sh
# Soal 11 - Reverse Proxy abbey (Nginx) ke Core

apk add nginx iproute2 nano openrc

mkdir -p /run/openrc
touch /run/openrc/softlevel
mkdir -p /etc/nginx/conf.d

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > /etc/nginx/conf.d/abbey.conf << 'EOF'
server {
    listen 80;
    server_name abbey.k63.com static.k63.com;

    location / {
        proxy_pass http://10.95.30.6;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

killall nginx 2>/dev/null
nginx

echo "=== Test ==="
curl http://localhost
curl http://abbey.k63.com
curl http://static.k63.com

echo "abbey done!"


# -------------------------------------------------------------------
# Run di alpha

# Test penny → vault
curl http://www.k63.com
curl http://penny.k63.com

# Test abbey → core
curl http://static.k63.com
curl http://abbey.k63.com

# Test header forwarding
curl -H "X-Real-IP: 10.95.10.2" http://www.k63.com
curl -H "X-Real-IP: 10.95.10.2" http://static.k63.com

# --------------------------------------------------------------------------------------
# Verifikasi Header Forwarding
# Run di obladi
# obladi (Apache Backend - Log Format)

#!/bin/sh
# Soal 11 - Fix Log Format di obladi

cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName obladi.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Forwarded-For}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "obladi log done!"

# --------------------------------------------------------------------------------
# Run di desmond

#!/bin/sh
# Soal 11 - Fix Log Format di desmond

apk add apache2-ctl

cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName desmond.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Forwarded-For}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "desmond log done!"

# Verifikasi 
curl http://localhost
curl http://desmond.k63.com

# oblada (Nginx Backend - Log Format)
# Run di oblada

#!/bin/sh
# Soal 11 - Fix Log Format di oblada

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_forwarded_for - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

nginx -s reload

echo "oblada log done!"


# --------------------------------------------------------------------------------------------------
# molly (Nginx Backend - Log Format)

#!/bin/sh
# Soal 11 - Fix Log Format di molly

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_forwarded_for - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

nginx -s reload

echo "molly log done!"


# ----------------------------------------------------------------------
# Verifikasi Soal 11 (Semua)
# Run di alpha

# Test penny → vault
curl http://www.k63.com
curl http://penny.k63.com

# Test abbey → core
curl http://static.k63.com
curl http://abbey.k63.com

# ------------------------------------------------
# Run di obladi

tail -5 /var/log/apache2/access.log

# ---------------------------------------------------------------------
# Run di oblada

tail -5 /var/log/nginx/access.log











# Run di: oblada

# Cek access log
tail -f /var/log/nginx/access.log

#!/bin/sh
# Soal 9 - Web Statis (Apache) di obladi - Alpine - SIMPLE

apk add apache2 apache2-ctl iproute2 nano openrc

mkdir -p /run/openrc
touch /run/openrc/softlevel

mkdir -p /arsip
echo "<h1>Static Archive - obladi</h1>" > /arsip/index.html
echo "file1" > /arsip/file1.txt
echo "file2" > /arsip/file2.txt

cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName obladi.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Real-IP}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

killall httpd 2>/dev/null
/usr/sbin/apachectl start

echo "=== Test ==="
curl http://localhost
curl http://obladi.k63.com

echo "obladi done!"
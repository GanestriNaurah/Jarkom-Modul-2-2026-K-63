# TTL Testing
# prab (ubah IP abbey ke IP fiktif)
# Run di prab

#!/bin/sh
# Soal 18 - TTL Testing di prab

# Edit zone file, ubah IP abbey ke IP fiktif
sed -i 's/abbey   IN  A       10.95.20.2/abbey   IN  A       10.95.99.99/' /var/bind/pri/db.k63.com

# Naikkan serial
sed -i 's/2026093001/2026093002/' /var/bind/pri/db.k63.com

# Restart named
killall named
named -u named

echo "TTL change done!"

# alpha (verifikasi 3 fase)
# Run di alpha

#!/bin/sh
# Soal 18 - Verifikasi TTL 3 fase

echo "=== Fase 1: Sebelum perubahan ==="
dig abbey.k63.com

echo ""
echo "=== Fase 2: Dalam 15 detik (cache) ==="
sleep 5
dig abbey.k63.com

echo ""
echo "=== Fase 3: Setelah TTL habis ==="
sleep 15
dig abbey.k63.com

echo ""
echo "TTL test done!"

# Verifikasi Zone Transfer
# Run di tedd

dig @10.95.30.2 k63.com SOA
dig @10.95.30.3 k63.com SOA
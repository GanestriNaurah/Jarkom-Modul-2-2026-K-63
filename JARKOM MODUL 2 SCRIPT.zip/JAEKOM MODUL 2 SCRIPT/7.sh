# Verifikasi dari 2 Klien Berbeda
# Run di alpha

dig vault.k63.com
dig core.k63.com
dig www.k63.com
dig static.k63.com


# -----------------------------------------------
# Run di beta

dig vault.k63.com
dig core.k63.com
dig www.k63.com
dig static.k63.com
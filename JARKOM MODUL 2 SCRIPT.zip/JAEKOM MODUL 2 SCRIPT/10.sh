# Run di oblada

#!/bin/sh
# Soal 10 - Web Dinamis (Nginx + PHP-FPM) di oblada - Alpine - FIXED

apk add nginx php-fpm php-cli iproute2 nano openrc

mkdir -p /run/openrc
touch /run/openrc/softlevel

mkdir -p /var/www/core
cat > /var/www/core/index.php << 'EOF'
<?php
echo "<h1>Beranda Core</h1>";
?>
EOF

cat > /var/www/core/profil.php << 'EOF'
<?php
echo "<h1>Profil Core</h1>";
?>
EOF

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_real_ip - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

rm -f /etc/nginx/http.d/default.conf

nginx -t
killall nginx php-fpm84 2>/dev/null
php-fpm84
sleep 2
nginx

echo "=== Test ==="
curl http://localhost
curl http://localhost/profil
curl http://oblada.k63.com
curl http://oblada.k63.com/profil

echo "oblada done!"




# ------------------------------------------------------------------
# Run di molly


#!/bin/sh
# Soal 10 - Web Dinamis (Nginx + PHP-FPM) di molly - Alpine - FIXED

apk add nginx php-fpm php-cli iproute2 nano openrc

mkdir -p /run/openrc
touch /run/openrc/softlevel

mkdir -p /var/www/core
cat > /var/www/core/index.php << 'EOF'
<?php
echo "<h1>Beranda Core</h1>";
?>
EOF

cat > /var/www/core/profil.php << 'EOF'
<?php
echo "<h1>Profil Core</h1>";
?>
EOF

mkdir -p /etc/nginx/conf.d

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_real_ip - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

rm -f /etc/nginx/http.d/default.conf

nginx -t
killall nginx php-fpm84 2>/dev/null
php-fpm84
sleep 2
nginx

echo "=== Test ==="
curl http://localhost
curl http://localhost/profil
curl http://molly.k63.com
curl http://molly.k63.com/profil

echo "molly done!"

# ------------------------------------------------------------------------------
# Run di alpha

curl http://oblada.k63.com
curl http://oblada.k63.com/profil
curl http://molly.k63.com
curl http://molly.k63.com/profil
curl http://core.k63.com
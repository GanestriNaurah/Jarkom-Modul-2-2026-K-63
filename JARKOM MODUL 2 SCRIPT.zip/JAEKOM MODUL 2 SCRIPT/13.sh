# penny (301 → www.k63.com)
# Run di penny

#!/bin/sh
# Soal 13 - Redirect 301 di penny - FULL REVISI

# Buat config redirect terpisah
cat > /etc/apache2/conf.d/penny-redirect.conf << 'EOF'
<VirtualHost *:80>
    ServerName penny.k63.com
    Redirect 301 / http://www.k63.com/
</VirtualHost>
EOF

# Restart Apache
/usr/sbin/apachectl restart

# Verifikasi
echo "=== Test Redirect 301 ==="
curl -I http://penny.k63.com
curl -I http://10.95.40.2

echo "penny redirect done!"

# ------------------------------------------------------------------------------------
# abbey (302 → static.k63.com)
# Run di abbey

#!/bin/sh
# Soal 13 - Redirect 302 di abbey - FULL REVISI

# Buat config redirect terpisah
cat > /etc/nginx/conf.d/abbey-redirect.conf << 'EOF'
server {
    listen 80;
    server_name abbey.k63.com;
    return 302 http://static.k63.com$request_uri;
}
EOF

# Reload nginx
nginx -s reload

# Verifikasi
echo "=== Test Redirect 302 ==="
curl -I http://abbey.k63.com
curl -I http://10.95.20.2

echo "abbey redirect done!"

# ------------------------------------------------------------------------------------------------
# Verifikasi Soal 13 (Semua)
# Run di alpha

# Test redirect 301 (penny → www)
curl -I http://penny.k63.com

# Test redirect 302 (abbey → static)
curl -I http://abbey.k63.com

# Test redirect via IP
curl -I http://10.95.40.2
curl -I http://10.95.20.2
# alpha (ApacheBench Stress Test)
# Run di alpha

#!/bin/sh
# Soal 16 - Stress Test

apk add apache2-utils

echo "=== Stress Test www.k63.com ==="
ab -n 250 -c 10 http://www.k63.com/

echo ""
echo "=== Stress Test static.k63.com ==="
ab -n 250 -c 10 http://static.k63.com/

echo ""
echo "stress test done!"

# ------------------------------------------------------------------------------------------------------
# Verifikasi
# Run di alpha

ab -n 250 -c 10 http://www.k63.com/
ab -n 250 -c 10 http://static.k63.com/



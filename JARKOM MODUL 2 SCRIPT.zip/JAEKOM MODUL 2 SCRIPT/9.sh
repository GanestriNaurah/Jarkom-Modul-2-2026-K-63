# Run di obladi

#!/bin/sh
# Soal 9 - Web Statis (Apache) di obladi - Alpine - FULL

# Install packages
apk add apache2 iproute2 nano openrc

# Setup openrc
mkdir -p /run/openrc
touch /run/openrc/softlevel

# Buat direktori arsip
mkdir -p /arsip
echo "<h1>Static Archive - obladi</h1>" > /arsip/index.html
echo "file1" > /arsip/file1.txt
echo "file2" > /arsip/file2.txt

# Konfigurasi Apache
cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName obladi.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Real-IP}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

# Start Apache
httpd -k start

# Verifikasi
echo "=== Cek Apache ==="
ps aux | grep httpd | grep -v grep

echo "=== Cek Listen ==="
netstat -tlnp | grep 80

echo "=== Test localhost ==="
curl http://localhost

echo "=== Test hostname ==="
curl http://obladi.k63.com

echo "=== Test autoindex ==="
rm /arsip/index.html
curl http://localhost/

echo "obladi apache done!"


# ------------------------------------------------------------
# Run di desmond

#!/bin/sh
# Soal 9 - Web Statis (Apache) di desmond - Alpine - FULL

# Install packages
apk add apache2 iproute2 nano openrc

# Setup openrc
mkdir -p /run/openrc
touch /run/openrc/softlevel

# Buat direktori arsip
mkdir -p /arsip
echo "<h1>Static Archive - desmond</h1>" > /arsip/index.html
echo "file1" > /arsip/file1.txt
echo "file2" > /arsip/file2.txt

# Konfigurasi Apache
cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName desmond.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Real-IP}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

# Start Apache
httpd -k start

# Verifikasi
echo "=== Cek Apache ==="
ps aux | grep httpd | grep -v grep

echo "=== Cek Listen ==="
netstat -tlnp | grep 80

echo "=== Test localhost ==="
curl http://localhost

echo "=== Test hostname ==="
curl http://desmond.k63.com

echo "=== Test autoindex ==="
rm /arsip/index.html
curl http://localhost/

echo "desmond apache done!"


# Verifikasi desmond

curl http://localhost
curl http://desmond.k63.com
rm /arsip/index.html
curl http://localhost/


# ---------------------------------------------------------------------
# Verifikasi Soal 9
# Run di: alpha

# Test via hostname
curl http://obladi.k63.com
curl http://desmond.k63.com
curl http://vault.k63.com

# Test autoindex (directory listing)
curl http://obladi.k63.com/
curl http://desmond.k63.com/
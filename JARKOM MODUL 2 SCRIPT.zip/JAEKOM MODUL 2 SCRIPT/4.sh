#!/bin/sh
# Soal 4 - DNS Master (prab) - Alpine - FULL WORKING

# Install packages
apk add bind bind-tools iproute2 nano openrc

# Buat direktori
mkdir -p /run/openrc
touch /run/openrc/softlevel
mkdir -p /var/bind/pri /var/bind/slave
chown named:named /var/bind

# Forward zone
cat > /var/bind/pri/db.k63.com << 'EOF'
$TTL 604800
@   IN  SOA prab.k63.com. admin.k63.com. (
        2026093001  ; Serial
        86400       ; Refresh
        7200        ; Retry
        3600000     ; Expire
        86400 )     ; Minimum TTL

@       IN  NS      prab.k63.com.
@       IN  NS      tedd.k63.com.

@       IN  A       10.95.40.2
prab    IN  A       10.95.30.2
tedd    IN  A       10.95.30.3

alpha   IN  A       10.95.10.2
beta    IN  A       10.95.10.3
gamma   IN  A       10.95.10.4
delta   IN  A       10.95.50.3
epsilon IN  A       10.95.50.2

abbey   IN  A       10.95.20.2
penny   IN  A       10.95.40.2

obladi  IN  A       10.95.30.4
desmond IN  A       10.95.30.5
oblada  IN  A       10.95.30.6
molly   IN  A       10.95.30.7

vault   IN  A       10.95.30.4
vault   IN  A       10.95.30.5
core    IN  A       10.95.30.6
core    IN  A       10.95.30.7

www     IN  CNAME   penny.k63.com.
static  IN  CNAME   abbey.k63.com.

alpha   IN  TXT     "alpha"
beta    IN  TXT     "beta"
gamma   IN  TXT     "gamma"
delta   IN  TXT     "delta"
epsilon IN  TXT     "epsilon"

outbound IN CNAME   http.badssl.com.
EOF

# Reverse zone 10.95.30.x
cat > /var/bind/pri/db.30.95.10 << 'EOF'
$TTL 604800
@   IN  SOA prab.k63.com. admin.k63.com. (
        2026093001  ; Serial
        86400       ; Refresh
        7200        ; Retry
        3600000     ; Expire
        86400 )     ; Minimum TTL

@       IN  NS      prab.k63.com.
@       IN  NS      tedd.k63.com.

2       IN  PTR     abbey.k63.com.
4       IN  PTR     obladi.k63.com.
5       IN  PTR     desmond.k63.com.
6       IN  PTR     oblada.k63.com.
7       IN  PTR     molly.k63.com.
EOF

# Reverse zone 10.95.20.x
cat > /var/bind/pri/db.20.95.10 << 'EOF'
$TTL 604800
@   IN  SOA prab.k63.com. admin.k63.com. (
        2026093001  ; Serial
        86400       ; Refresh
        7200        ; Retry
        3600000     ; Expire
        86400 )     ; Minimum TTL

@       IN  NS      prab.k63.com.
@       IN  NS      tedd.k63.com.

2       IN  PTR     abbey.k63.com.
EOF

# Named config utama
cat > /etc/bind/named.conf << 'EOF'
include "/etc/bind/named.conf.options";
include "/etc/bind/named.conf.local";
EOF

# Options
cat > /etc/bind/named.conf.options << 'EOF'
options {
    directory "/var/bind";
    listen-on { any; };
    listen-on-v6 { none; };
    allow-query { any; };
    recursion yes;
    allow-recursion { any; };
};
EOF

# Local zones
cat > /etc/bind/named.conf.local << 'EOF'
zone "k63.com" {
    type master;
    file "/var/bind/pri/db.k63.com";
    allow-transfer { 10.95.30.3; };
    also-notify { 10.95.30.3; };
    forwarders { 192.168.122.1; };
};

zone "30.95.10.in-addr.arpa" {
    type master;
    file "/var/bind/pri/db.30.95.10";
    allow-transfer { 10.95.30.3; };
    also-notify { 10.95.30.3; };
};

zone "20.95.10.in-addr.arpa" {
    type master;
    file "/var/bind/pri/db.20.95.10";
    allow-transfer { 10.95.30.3; };
    also-notify { 10.95.30.3; };
};
EOF

# Resolver
cat > /etc/resolv.conf << 'EOF'
nameserver 10.95.30.2
nameserver 10.95.30.3
nameserver 192.168.122.1
EOF

# Fix permission
chown -R named:named /var/bind
chmod 755 /var/bind

# Start named
named -u named

echo "prab DNS done!"

#Verifikasi

dig @127.0.0.1 k63.com
dig @127.0.0.1 www.k63.com
dig @127.0.0.1 prab.k63.com
dig @127.0.0.1 -x 10.95.20.2
dig @127.0.0.1 -x 10.95.30.4
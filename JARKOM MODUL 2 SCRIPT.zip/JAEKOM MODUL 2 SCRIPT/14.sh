#Run di penny

#!/bin/sh
# Soal 14 - Fix Header Forwarding di penny

cat > /etc/apache2/conf.d/penny.conf << 'EOF'
<VirtualHost *:80>
    ServerName penny.k63.com
    ServerAlias www.k63.com

    ProxyPreserveHost On

    ProxyPass / http://10.95.30.4/
    ProxyPassReverse / http://10.95.30.4/

    RequestHeader set X-Forwarded-For "%{REMOTE_ADDR}s"
    RequestHeader set Host "obladi.k63.com"

    ErrorLog /var/log/apache2/penny_error.log
    CustomLog /var/log/apache2/penny_access.log combined
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "penny header done!"

# ---------------------------------------------------------------------------------
# Run di abbey

#!/bin/sh
# Soal 14 - Fix Header Forwarding di abbey

cat > /etc/nginx/conf.d/abbey.conf << 'EOF'
server {
    listen 80;
    server_name abbey.k63.com static.k63.com;

    location / {
        proxy_pass http://10.95.30.6;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

nginx -s reload

echo "abbey header done!"

# ---------------------------------------------------------------------------------
# Run di obladi

#!/bin/sh
# Soal 14 - Access Log Real IP di obladi

cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName obladi.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Forwarded-For}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "=== Test ==="
curl http://localhost
tail -5 /var/log/apache2/access.log

echo "obladi log done!"

# ---------------------------------------------------------------------------------
# Run di desmond

#!/bin/sh
# Soal 14 - Access Log Real IP di desmond

cat > /etc/apache2/conf.d/arsip.conf << 'EOF'
<VirtualHost *:80>
    ServerName desmond.k63.com
    DocumentRoot /arsip

    <Directory /arsip>
        Options +Indexes
        AllowOverride None
        Require all granted
    </Directory>

    LogFormat "%{X-Forwarded-For}i %l %u %t \"%r\" %>s %b" realip
    CustomLog /var/log/apache2/access.log realip
</VirtualHost>
EOF

/usr/sbin/apachectl restart

echo "=== Test ==="
curl http://localhost
tail -5 /var/log/apache2/access.log

echo "desmond log done!"

# ----------------------------------------------------------------------------------
# Run di oblada 

#!/bin/sh
# Soal 14 - Access Log Real IP di oblada

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_forwarded_for - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

nginx -s reload

echo "=== Test ==="
curl http://localhost
tail -5 /var/log/nginx/access.log

echo "oblada log done!"

# ----------------------------------------------------------------------------------------
# Run di molly

#!/bin/sh
# Soal 14 - Access Log Real IP di molly

cat > /etc/nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    log_format realip '$http_x_forwarded_for - $remote_user [$time_local] "$request" '
                       '$status $body_bytes_sent "$http_referer" '
                       '"$http_user_agent"';

    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > /etc/nginx/conf.d/core.conf << 'EOF'
server {
    listen 80;
    server_name oblada.k63.com molly.k63.com;
    root /var/www/core;
    index index.php index.html;

    location / {
        try_files $uri $uri/ =404;
    }

    location /profil {
        rewrite ^/profil$ /profil.php last;
    }

    location ~ \.php$ {
        include fastcgi_params;
        fastcgi_pass 127.0.0.1:9000;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    access_log /var/log/nginx/access.log realip;
}
EOF

nginx -s reload

echo "=== Test ==="
curl http://localhost
tail -5 /var/log/nginx/access.log

echo "molly log done!"

# --------------------------------------------------------------------------------------
# Run di alpha

curl http://www.k63.com
curl http://static.k63.com

# --------------------------------------------------------------------------------------
# Run di obladi 

tail -5 /var/log/apache2/access.log

# ------------------------------------------------------------------------
# Run di desmond 

tail -5 /var/log/apache2/access.log

# --------------------------------------------------------------------------------------
# Run di oblada

tail -5 /var/log/nginx/access.log

# --------------------------------------------------------------------------------------
# Run di molly

tail -5 /var/log/nginx/access.log

# --------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------